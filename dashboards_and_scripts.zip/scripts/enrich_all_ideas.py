# scripts/enrich_all_ideas.py
from src.agents.trend_agent import estimate_market_size
from src.utils.metadata_writer import insert_score_metadata
import sqlite3

def main():
    conn = sqlite3.connect("idea.db")
    cursor = conn.cursor()
    cursor.execute("SELECT id, title, vertical FROM ideas")
    ideas = cursor.fetchall()

    for idea_id, title, vertical in ideas:
        print(f"Enriching: {title}")
        metadata = [estimate_market_size(vertical or title)]
        insert_score_metadata("idea.db", idea_id, metadata)

    conn.close()
    print("✅ All ideas enriched successfully.")

if __name__ == "__main__":
    main()
