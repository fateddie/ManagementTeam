# dashboards/score_dashboard.py
import streamlit as st
import sqlite3
import pandas as pd

st.set_page_config(page_title="Idea Score Dashboard", layout="wide")

st.title("📊 Idea Score Dashboard")

# Connect to database
conn = sqlite3.connect("idea.db")
df_ideas = pd.read_sql_query("SELECT * FROM ideas", conn)
df_meta = pd.read_sql_query("SELECT * FROM score_metadata", conn)

for _, idea in df_ideas.iterrows():
    st.subheader(idea["title"])
    st.write(f"Description: {idea.get('description', 'No description available')}")

    idea_meta = df_meta[df_meta["idea_id"] == idea["id"]]
    for _, row in idea_meta.iterrows():
        st.markdown(f"**{row['category'].title()} Score**: {row['score']}/10")
        st.markdown(f"🔍 *Justification*: {row['justification']}")
        st.caption(f"Source: {row['source']} | Confidence: {row['confidence_score']}/10")
        st.markdown("---")
